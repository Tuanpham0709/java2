/*  
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab1;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class CheckDay {

    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập vào một số từ 0 - 6: ");
        int day = Integer.parseInt(sc.nextLine());
        if(Weekday.Saturday == day || Weekday.Sunday == day){
            System.out.println("Ngày cuối tuần");
        }else{
            System.out.println("Ngày trong tuần");
        }
              
        
    }
}
